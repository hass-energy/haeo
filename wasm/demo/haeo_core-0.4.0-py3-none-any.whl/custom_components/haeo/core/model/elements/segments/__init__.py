"""Connection segment types for composable connection architecture.

Each segment type applies a specific transformation or constraint to power flow:
- EfficiencySegment: Applies efficiency losses
- PassthroughSegment: Lossless passthrough (no constraints)
- PowerLimitSegment: Limits power flow
- PricingSegment: Adds transfer pricing costs
- SocPricingSegment: Adds SOC-based pricing penalties
"""

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Final, Literal, TypeGuard

from highspy import Highs
from highspy.highs import HighspyArray
import numpy as np
from numpy.typing import NDArray

from custom_components.haeo.core.model.element import Element

from .efficiency import EfficiencySegment, EfficiencySegmentSpec
from .passthrough import PassthroughSegment, PassthroughSegmentSpec
from .power_limit import PowerLimitSegment, PowerLimitSegmentSpec
from .pricing import PricingSegment, PricingSegmentSpec
from .segment import Segment
from .soc_pricing import SocPricingSegment, SocPricingSegmentSpec

# Discriminated union of segment type strings
type SegmentType = Literal["efficiency", "passthrough", "power_limit", "pricing", "soc_pricing"]

# Union type for all segment specifications
type SegmentSpec = (
    EfficiencySegmentSpec | PassthroughSegmentSpec | PowerLimitSegmentSpec | PricingSegmentSpec | SocPricingSegmentSpec
)


def is_efficiency_spec(spec: SegmentSpec) -> TypeGuard[EfficiencySegmentSpec]:
    """Return True when spec is for an efficiency segment."""
    return spec["segment_type"] == "efficiency"


def is_passthrough_spec(spec: SegmentSpec) -> TypeGuard[PassthroughSegmentSpec]:
    """Return True when spec is for a passthrough segment."""
    return spec["segment_type"] == "passthrough"


def is_power_limit_spec(spec: SegmentSpec) -> TypeGuard[PowerLimitSegmentSpec]:
    """Return True when spec is for a power limit segment."""
    return spec["segment_type"] == "power_limit"


def is_pricing_spec(spec: SegmentSpec) -> TypeGuard[PricingSegmentSpec]:
    """Return True when spec is for a pricing segment."""
    return spec["segment_type"] == "pricing"


def is_soc_pricing_spec(spec: SegmentSpec) -> TypeGuard[SocPricingSegmentSpec]:
    """Return True when spec is for a SOC pricing segment."""
    return spec["segment_type"] == "soc_pricing"


@dataclass(frozen=True, slots=True)
class SegmentSpecEntry:
    """Specification for a segment type."""

    factory: Callable[..., Segment]


# Registry mapping segment type strings to segment factories
SEGMENTS: Final[dict[SegmentType, SegmentSpecEntry]] = {
    "efficiency": SegmentSpecEntry(factory=EfficiencySegment),
    "passthrough": SegmentSpecEntry(factory=PassthroughSegment),
    "power_limit": SegmentSpecEntry(factory=PowerLimitSegment),
    "pricing": SegmentSpecEntry(factory=PricingSegment),
    "soc_pricing": SegmentSpecEntry(factory=SocPricingSegment),
}


def create_segment(
    *,
    segment_id: str,
    n_periods: int,
    periods: NDArray[np.floating[Any]],
    solver: Highs,
    spec: SegmentSpec,
    source_element: Element[Any],
    target_element: Element[Any],
    power_in: dict[int, HighspyArray],
) -> Segment:
    """Create a segment instance from a segment specification."""
    segment_type = spec["segment_type"]
    entry = SEGMENTS[segment_type]
    return entry.factory(
        segment_id,
        n_periods,
        periods,
        solver,
        spec=spec,
        source_element=source_element,
        target_element=target_element,
        power_in=power_in,
    )


__all__ = [
    "SEGMENTS",
    "EfficiencySegment",
    "EfficiencySegmentSpec",
    "PassthroughSegment",
    "PassthroughSegmentSpec",
    "PowerLimitSegment",
    "PowerLimitSegmentSpec",
    "PricingSegment",
    "PricingSegmentSpec",
    "Segment",
    "SegmentSpec",
    "SegmentSpecEntry",
    "SegmentType",
    "SocPricingSegment",
    "SocPricingSegmentSpec",
    "create_segment",
    "is_efficiency_spec",
    "is_passthrough_spec",
    "is_power_limit_spec",
    "is_pricing_spec",
    "is_soc_pricing_spec",
]
