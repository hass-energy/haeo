"""Per-element adapter modules."""
