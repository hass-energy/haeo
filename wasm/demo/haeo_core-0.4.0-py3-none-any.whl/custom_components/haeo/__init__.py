"""HAEO Core - standalone optimization engine."""
